#include <stdio.h>
#include "board.h"
#include <unistd.h>
#include <stdlib.h>
#define TAILLENOM 16
// fonctions pour système de classement 

typedef struct{
	int ELO;
	char login[TAILLENOM];
	char pswd[TAILLENOM];
}personne;

int len(char nom[]){
   int i=0;
   while(nom[i]!='\0'){
      i++;
   }
   return i;
}

void affiche_mdp(char pswd[]){
   int i=0;
   while(pswd[i]!='\0'){
      printf("%c",pswd[i]);
      i++;
   }
   printf("\n");  
}

void affiche_nom(char login[], char nomjoueur[]){
	int a=0;
	while(login[a]!=0){
		nomjoueur[a] = login[a];
		printf("%c",nomjoueur[a]);
		a++;
	}
	printf(" ");
}

int comparateur_string(char str[],char str2[]){
   int i=0;
   if(len(str)!=len(str2)){
      return 0;
   }
   while(str[i]==str2[i]){
      i++;
   }
   return 1;
}

void copy(personne player ,char pswd[]){
   int i=0;
   while(pswd[i]!='\0'){
      player.pswd[i]=pswd[i];
      i++;
   }
}

int checker(char str[]){
	FILE *F = fopen("database.txt","r");
	int i=0;char c;
	while(fscanf(F,"%c",&c)!=EOF){
      if(c==str[i]){
         if(i+1==len(str)){
            return 1;
		}
		
	}
	else{
		i=0;
	}
	i++;
}
fclose(F);
	return 0;
}
	

int get_elo(personne player){
	FILE *F =fopen("database.txt","r");
	char c;char cherche[TAILLENOM];int j=0; int i=0;
	while(fscanf(F,"%c",&c)!=EOF){
      if(c==player.pswd[i]){
         if(i+1==len(player.pswd)){
			 fscanf(F,"%c",&c);
			 fscanf(F,"%c",&c);
			 while(c!='\n'){
				 cherche[j]=c;
				 fscanf(F,"%c",&c);
				 j++;
			 } 
		}
	}
	else{
		i=0;
	}
	i++;
}
fclose(F);
int res = atoi(cherche);
return res;
}
	
	
void update_elo(personne *player){
	FILE *F=fopen("database.txt","r+");
	int elo = player->ELO;
	char c;int i=0;
	while(fscanf(F,"%c",&c)!=EOF){
      if(c==player->pswd[i]){
         if(i+1==len(player->pswd)){
			 fscanf(F,"%c",&c);
			 fprintf(F,"%d",elo);
			 } 
		}
	
	else{
		i=0;
	}
	i++;
}
fclose(F);	
}

/*
void classement(){
	printf("Voici le classement actuel : \n");
	FILE *F=fopen("database.txt","r");
	char c;int i=0;char s[TAILLENOM];
	while(fscanf(F,"%c",&c)!=EOF){
		while(c!='\n'){
			s[i] = c;
			i++;
			fscanf(F,"%c",&c);
		}
		for(int a=0;a<3;a++){
			fscanf(F,"%c",&c);
		}
		i=0;
		while(s[i]!='\0'){
			printf("%c",s[i]);
			i++;
		}
		
	}
	fclose(F);	
}
*/

	



//fonctions de base du jeu goblets gobbers
/* fonction qui vérifie que le caractère rentré dans le scanf est bien un entier, et redemande sinon */
void DORBECTRAP(int * a){
	while(scanf("%d",a)==0){
		getchar();
		printf("Please, choose a number\n");
	}
}

/* fonction qui demande au joueur de choisir une case dans laquelle placer son pion ,
 *  et vérifie que le joueur rentre bien un entier, grâce à la fonction DORBECTRAP */
void choixjoueur(int * line,int * column){
	printf("Choose  the column which you want to play in (between 0 and 2)\n");
	scanf("%d",column);
	while( 0> * column || * column > 2){
		printf("Please choose an available column(BETWEEEN 0 AND 2 !)\n");
		DORBECTRAP(column);
	}
	printf("Choose  the line which you want to play in (between 0 and 2)\n");
	scanf("%d",line);
	while( 0> * line || * line > 2){
		printf("Please choose an available line(BETWEEEN 0 AND 2 !)\n");
		DORBECTRAP(line);
	}
			
}


/* fonction qui affiche le plateau, avec en blanc,les cases neutres, en bleu, les cases du joueur1 et en rose, les cases du joueur2 */


void afficheplateau(struct board_s *board){

	for(int a=0;a<DIMENSIONS;a++){
		for(int b=0;b<DIMENSIONS;b++){
			if(get_place_holder(board,a,b)==1){
				printf("\033[34;01m| %d |\033[00m",get_piece_size(board,a,b));
			}
			else if(get_place_holder(board,a,b)==2){	
				printf("\033[35;01m| %d |\033[00m",get_piece_size(board,a,b));
			}			
			else if(get_place_holder(board,a,b) == 0){
				
				printf("\033[33;01m| %d |\033[00m",get_piece_size(board,a,b));
			}
			
		}
	printf("\n");
	}

}
/* affichage réccurent de toutes les erreurs possible au début de chaque tour*/
void affiche_debut(){
		printf("\33[H\33[2J"); // le programme clear le terminal a chaque boucle, pour un jeu plus aéré et agréable 
		printf("Error type : \n");
		printf("0 : SUCCESS: the move is successful \n");
		printf("1 : POSITION: line or column do not correspond to a valid position \n");
		printf("2 : SOURCE: there is no visible piece belonging to the player on the corresponding place \n");
		printf("3 TARGET: a piece was available, but too small to be put at the target place.\n");
}

/* fonction qui demande au joueur son nom */
	
void start(char nom[]){
	printf("Enter the name of the player : \n");
	scanf("%s",nom);
}			


int main(){ 
	/* initialisation de toutes les variables*/
	FILE * F = fopen("database.txt","r");

	int choix_type_joueur;int player_checked;
	personne player1;
	personne player2;
	char c;int i=0;int j=0;char c1;
	char pswd[TAILLENOM]= "coucou";
	char pswd2[TAILLENOM]= "coucou";
	char nom_joueur1[TAILLENOM],nom_joueur2[TAILLENOM];                                                                           
	printf("Do you want to login [1], play as a guest [2] or register [3] ?");
	scanf("%d",&choix_type_joueur);
	while(choix_type_joueur!=1 && choix_type_joueur!=2 && choix_type_joueur !=3){
		printf("Please choose an available type of login\n");
		DORBECTRAP(&choix_type_joueur);
	}
	if (choix_type_joueur==1){
   printf("ENTER YOUR LOGIN\n");
   scanf("%s",player1.login);
   fclose(F);
   while(!(checker(player1.login))){
	   printf("PLS CHOOSE AN AVAILABLE LOGIN\n");
	   scanf("%s",player1.login);
   }
   FILE * F = fopen("database.txt","r");
   while(fscanf(F,"%c",&c)!=EOF){
      if(c==player1.login[i]){
         if(i+1==len(player1.login)){
            fscanf(F,"%c",&c);
            fscanf(F,"%c",&c);
            while(c!='\n'){

               pswd[j]=c;
               fscanf(F,"%c",&c);
               j++;
            }
            printf("Please, enter your password\n");
            scanf("%s",player1.pswd);
            while(!(comparateur_string(player1.pswd,pswd))){
               printf("WRONG PASSWORD, PLEASE TRY AGAIN \n");
               scanf("%s",player1.pswd);
            }
            copy(player1,pswd);
            player_checked=1;
            break;
         }
         i++;
      }
      else{
		  
         i=0;
      }
   }
   if(player_checked==1){
   printf("player 1 is logged on ");
      affiche_mdp(player1.login);
      player_checked=0;
      fclose(F);
      
  }
  
   }
   else if(choix_type_joueur==2){
      printf("PLEASE SELECT A GUEST NAME\n");
      scanf("%s",nom_joueur1);
      printf("player 1 is playing as ");
      affiche_nom(nom_joueur1,player1.login);
      fclose(F);
   }
   
   else{
	   fclose(F);
	   FILE * F1= fopen("database.txt","a+");
	   fprintf(F1,"\n");
	   printf("Enter a username : \n");
	   scanf("%s",player1.login);
	   fprintf(F1,"%s",player1.login);
	   fprintf(F1,"\n");
	   printf("Enter a password : \n");
	   scanf("%s",player1.pswd);
	   fprintf(F1,"%s",player1.pswd);
	   fprintf(F1,"\n");
	   fprintf(F1,"50");
	   fprintf(F1,"\n");
	   fclose(F1);
	   player1.ELO=50;
   }
   
   FILE *F2=fopen("database.txt","r");
   i=0;j=0;
   printf("Do you want to login [1], play as a guest [2] or register [3] ?\n");
   scanf("%d",&choix_type_joueur);
   while(choix_type_joueur!=1 && choix_type_joueur!=2 && choix_type_joueur !=3){
		printf("Please choose an available type of login\n");
		DORBECTRAP(&choix_type_joueur);
	}
   if (choix_type_joueur==1){
   printf("ENTER YOUR LOGIN\n");
   scanf("%s",player2.login);
   fclose(F2);
   while(!(checker(player2.login))){
	   printf("PLS CHOOSE AN AVAILABLE LOGIN\n");
	   scanf("%s",player2.login);
   }
   FILE * F2 = fopen("database.txt","r");
   while(fscanf(F2,"%c",&c1)!=EOF){
      if(c1==player2.login[i]){
         if(i+1==len(player2.login)){
            fscanf(F2,"%c",&c1);
            fscanf(F2,"%c",&c1);
            while(c1!='\n'){
               pswd2[j]=c1;
               fscanf(F2,"%c",&c1);
               j++;
            }
            printf("Please, enter your password\n");
            scanf("%s",player2.pswd);
            while(!(comparateur_string(player2.pswd,pswd2))){
               printf("WRONG PASSWORD, PLEASE TRY AGAIN\n");
               scanf("%s",player2.pswd);
            }
            copy(player2,pswd2);
            player_checked=1;
         }
         i++;
      }
      else{
         i=0;
      } 
      
   }
   if (player_checked==1){
   printf("player 2 is logged on \n");
    affiche_mdp(player2.login);
    fclose(F2);
  }
   }
   else if(choix_type_joueur==2){
      printf("PLEASE SELECT A GUEST NAME\n");
      scanf("%s",nom_joueur2);
      printf("player 2 is playing as \n");

      affiche_nom(nom_joueur2,player2.login);
         fclose(F2);
   }
   else{
	   fclose(F2);
	   FILE * F1= fopen("database.txt","a+");
	   fprintf(F1,"\n");
	   printf("Enter a username : \n");
	   scanf("%s",player2.login);
	   fprintf(F1,"%s",player2.login);
	   fprintf(F1,"\n");
	   printf("Enter a password : \n");
	   scanf("%s",player2.pswd);
	   fprintf(F1,"%s",player2.pswd);
	   fprintf(F1,"\n");
	   fprintf(F1,"50");
	   fprintf(F1,"\n");
	   fclose(F1);
	   player2.ELO=50;
   }


	printf("--------------------------------------\n");
	printf("------The game is about to start------\n"); 
	printf("--------------------------------------\n");
	int line,column,choixtour,choix_type_piece;
	int compteur =0;
	board game = new_game();
	printf("The board has been created.\n");	
	/* début du jeu, le programme demande au joueurs leurs nom, et affiche le plateau vide */
	player joueur=1;
	afficheplateau(game);
	while(get_winner(game)==NO_PLAYER){
		affiche_debut();
		afficheplateau(game); // a chaque début de tour, le programme affiche le plateau dans son état actuel
		printf("You still have : %d small piece(s), %d medium piece(s), %d large piece(s) in your house\n",get_nb_piece_in_house(game,joueur,SMALL),get_nb_piece_in_house(game,joueur,MEDIUM),get_nb_piece_in_house(game,joueur,LARGE));
		if(joueur==1){
			
		
			/* demande au joueur si il veut placer ou déplacer un pion, 
			 si c'est le premier tour, le joueur n'a pas le droit de déplacer un pion 
			 encore une fois, le programme vérifie que le choix du joueur est un entier, avec la fonction DORBECTRAP */
			 
			affiche_nom(player1.login,nom_joueur1);
			printf("What do you want to do : place a piece(type 1), move a piece (type 2) ?\n");
			scanf("%d",&choixtour);
			while(choixtour<1 ||choixtour>2 || (choixtour==2 && compteur<=1)){
				if((choixtour==2 && compteur<=1)){
					printf("You can't move a piece which isn't placed yet \n");
				}
				printf("What do you want to do : place a piece(type 1), move a piece(type 2) ?\n");
				DORBECTRAP(&choixtour);
			}
			
			/* si le joueur décide de placer un pion, alors le programme  :
			 vérifie que le joueur a encore des pions à placer;
			 lui demande à quelle case avec la fonction choixjoueur;
			 lui demande quel type de pièce il veut placer (SMALL,MEDIUM,LARGE);
			 vérifie bien que ce soit un entier (DORBECTRAP);
			 place le pion;
			 affiche une erreur si le placement est impossible;
			 affiche une erreur si le joueur n'a plus de pions */ 
			 
			if(choixtour==1){
				if(get_nb_piece_in_house(game,joueur,1) + get_nb_piece_in_house(game,joueur,2) + get_nb_piece_in_house(game,joueur,3) !=0){
					choixjoueur(&line,&column);
					printf("What type of piece do you want to place : SMALL(type 1), MEDIUM(type 2), LARGE(type 3) ?\n");
					scanf("%d",&choix_type_piece);
					while(choix_type_piece<1 ||choix_type_piece>3){
						printf("Please choose an available type : SMALL(type 1), MEDIUM(type 2), LARGE(type 3) ?\n");
						DORBECTRAP(&choix_type_piece);
					}
					int res = place_piece(game,choix_type_piece,line, column);
					
					if(res == OK){
						printf("The piece has been placed succesfully.\n");
						
						printf("You still have %d piece of this type\n",get_nb_piece_in_house(game,joueur,choix_type_piece));
					}
					else {
						printf("An issue has occured during the placement of the piece, error number %d \n", res);
	
					}
				}
				else{
					printf("Error, no more piece available");
		
				
				}
			}
			
			/* si le joueur décide de déplacer un pion, alors le programme :
			 vérifie que ce n'est pas le premier tour du joueur;
			 lui demande la position du pion qu'il veut bouger;
			 lui demande la position vers laquelle il veut bouger;
			 bouge le pion;
			 affiche un message d'erreur si le joueur essaies de bouger le pion adverse;
			 */
			 
			 
			else if(choixtour==2 ){
				if(compteur >1){
					printf("Which piece do you want to move ? \n");
					choixjoueur(&line,&column);
					int ligne1 = line;
					int colonne1=column;
					printf("Where do you want to move it ? \n");
					choixjoueur(&line,&column);
					if(get_place_holder(game,ligne1,colonne1)==1){
						move_piece(game,ligne1,colonne1,line,column);
						printf("The piece has been moved succesfully. \n");
						
					}
					else{
						printf("You can't move the opponent's  piece\n");
	
					}
					afficheplateau(game);
				}
			}
			if(get_winner(game)==PLAYER_1){
				break;
			}
			joueur=2;
			
		}
		else{ // tout le else est la même chose que le if, mais pour le deuxième joueur
			affiche_nom(player2.login,nom_joueur2);
			printf("What do you want to do : place a piece (type 1), move a piece(type 2) ?\n");
			scanf("%d",&choixtour);
			while(choixtour<1 ||choixtour>2){
				printf("What do you want to do : place a piece(type 1), move a piece(type 2) ?\n");
				DORBECTRAP(&choixtour);
			}
		
			if(choixtour==1){
				if(get_nb_piece_in_house(game,joueur,1) + get_nb_piece_in_house(game,joueur,2) + get_nb_piece_in_house(game,joueur,3) !=0){
					choixjoueur(&line,&column);
					printf("What type of piece do you want to place : SMALL(type 1), MEDIUM(type 2), LARGE(type 3) ?\n");
					scanf("%d",&choix_type_piece);
					while(choix_type_piece<1 ||choix_type_piece>3){
						printf("Please choose an available type : SMALL(type 1), MEDIUM(type 2), LARGE(type 3) ?\n");
						DORBECTRAP(&choix_type_piece);
					}
					int res = place_piece(game,choix_type_piece,line, column);
					
					if(res == OK){
						printf("The piece has been placed succesfully.\n");
						
						printf("You still have %d piece of this type\n",get_nb_piece_in_house(game,joueur,choix_type_piece));
					}
					else {
						printf("An issue has occured during the placement of the piece, error number %d \n", res);

					}
				}
				else{
					printf("Error, no more piece available");
				
				}
			}
			
			/* si le joueur décide de déplacer un pion, alors le programme :
			 vérifie que ce n'est pas le premier tour du joueur;
			 lui demande la position du pion qu'il veut bouger;
			 lui demande la position vers laquelle il veut bouger;
			 bouge le pion;
			 affiche un message d'erreur si le joueur essaies de bouger le pion adverse;
			 */
			 
			 
			else if(choixtour==2){
				if(compteur >1){
					printf("Which piece do you want to move ? \n");
					choixjoueur(&line,&column);
					int ligne1 = line;
					int colonne1=column;
					printf("Where do you want to move it ? \n");
					choixjoueur(&line,&column);
					if(get_place_holder(game,ligne1,colonne1)==2){
						move_piece(game,ligne1,colonne1,line,column);
						printf("The piece has been moved succesfully. \n");
						
					}
					else{
						printf("You can't move the opponent's  piece\n");
					}
					afficheplateau(game);
				}
			}
			if(get_winner(game)==PLAYER_2){
				break;
			}
			joueur=1;		
		}
		compteur ++;
		sleep(1);
		
		
	}
	
	/* Le programme annonce un gagnant et change l'élo des joueurs*/

	if(joueur==1){
		player1.ELO=get_elo(player1)+10;
		player2.ELO=get_elo(player2)-8;
		update_elo(&player1);
		update_elo(&player2);
		printf("%s est gagnant ! Son elo est de %d (+10) \n",nom_joueur1,player1.ELO);
		printf("%s est perdant ! Son elo est de %d (-8) \n",nom_joueur2,player2.ELO);
		
	}
	else{
		player2.ELO=get_elo(player2)+10;
		player1.ELO=get_elo(player1)-8;
		update_elo(&player1);
		update_elo(&player2);
		printf("%s est gagnant ! Son elo est de %d (+10)\n",nom_joueur2,player1.ELO);
		printf("%s est perdant ! Son elo est de %d (-8) \n",nom_joueur1,player2.ELO);
	}

	afficheplateau(game);
	destroy_game(game); 
	printf("Deleting the board and exiting\n");	
	
	return 0;
}


 

