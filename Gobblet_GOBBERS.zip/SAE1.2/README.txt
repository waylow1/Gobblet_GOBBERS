Nous avons choisi d'implémenter l'extension du classement, avec le système de connexion et d'ELO qui va avec . 

Le joueur se créer un compte qui est stocké dans le fichier "database.txt", et part de base avec 50 d'ELO. S'il gagne, son ELO augmente de 10, s'il perd, il descend de 8. Une fois enregistré, il peut se connecter à chaque début de partie s'il le souhaite.

Nous aurions voulu faire un classement, par ELO, de tous les joueurs enregistrés, mais par manque de temps nous n'avons pas pu. Cependant, notre prototype de fonction "classement" est restée en commentaire, de la ligne 126 à la ligne 149 de notre fichier "goblets_gobbers.c",mais ne marche pas correctement.

LEVESQUE Maxence
TOURBILLON Noé

