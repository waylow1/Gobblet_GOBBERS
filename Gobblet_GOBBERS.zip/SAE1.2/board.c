#include <stdio.h>
#include <stdlib.h>
#include "board.h"

/**
 * \file board.c
 *
 * \brief Source code associated with \ref board.h
 *
 * \author Maxence LEVESQUE Noé TOURBILLON
 */

/**
 * @brief The board of the game.
 */
 

struct board_s {
	int tabsize[DIMENSIONS][DIMENSIONS];
	player joueur;
	int tabplayer[DIMENSIONS][DIMENSIONS];
	int house1[4];
	int house2[4];
	int MEMOIRE[DIMENSIONS][DIMENSIONS];
};

board new_game(){
	board new_board = malloc(sizeof(struct board_s));
	new_board->joueur=NO_PLAYER;
	next_player(new_board);
	for(int i=0;i<DIMENSIONS;i++){
		for(int j=0;j<DIMENSIONS;j++){
			new_board->tabsize[i][j]=0;
			new_board->tabplayer[i][j]=0;
			new_board->MEMOIRE[i][j]=0;
		}
	}
	for(int c=0;c<DIMENSIONS+1;c++){
		new_board->house1[c] = 2;
		new_board->house2[c] = 2;
		
	}
	return new_board;
}

board copy_game(board original_game){
	board new_board = malloc(sizeof(struct board_s));
	for(int i=0;i<DIMENSIONS;i++){
		for(int j=0;j<DIMENSIONS;j++){
			new_board->tabsize[i][j]=original_game->tabsize[i][j];
			new_board->tabplayer[i][j] = original_game->tabplayer[i][j];
		}
		new_board->house1[i]= original_game->house1[i];
		new_board->house2[i]= original_game->house2[i];
	}	
	return new_board;
}

void destroy_game(board game){
	free(game);
};

// TODO ajouter les entêtes des autres fonctions et completer


player next_player(board game){
	if(game->joueur==0 || game->joueur==2){
		game->joueur=1;
		return game->joueur;
	}
	else{
		game->joueur=2;
		return game->joueur;
	}
}


player get_place_holder(board game, int line, int column){
	player joueur=NO_PLAYER;
	if(game->tabplayer[line][column]==0){
		joueur= NO_PLAYER;
		return joueur;
	}
	if(game->tabplayer[line][column]==1){
		joueur=PLAYER_1;
		return joueur;
	}	
	if(game->tabplayer[line][column]==2){
		joueur=PLAYER_2;
		return joueur;
	}
	return joueur;
}
	

size get_piece_size(board game, int line, int column){
	size piece=NONE;
	if(game->tabsize[line][column]==0){
		piece= NONE;
		return piece;
	}
	if(game->tabsize[line][column]==1){
		piece=SMALL;
		return piece;
	}	
	if(game->tabsize[line][column]==2){
		piece=MEDIUM;
		return piece;
	}	
	if(game->tabsize[line][column]==3){
		piece=LARGE;
		return piece;
	}
	return piece;
}


player get_winner(board game){
	player winner = NO_PLAYER;
	 
	if(game->tabplayer[0][0] == game->tabplayer[0][1] && game->tabplayer[0][0] == game->tabplayer[0][2]){
		if(game->tabplayer[0][0] == 1){
			winner = PLAYER_1;
		}
		if(game->tabplayer[0][0] == 2){
			winner = PLAYER_2;
		}
	}
	if(game->tabplayer[0][0] == game->tabplayer[1][0] && game->tabplayer[0][0] == game->tabplayer[2][0]){
		if(game->tabplayer[0][0] == 1){
			winner = PLAYER_1;
		}
		if(game->tabplayer[0][0] == 2){
			winner = PLAYER_2;
		}
	}
	if(game->tabplayer[2][0] == game->tabplayer[2][1] && game->tabplayer[2][0] == game->tabplayer[2][2]){
		if(game->tabplayer[2][0] == 1){
			winner = PLAYER_1;
		}
		if(game->tabplayer[2][0] == 2){
			winner = PLAYER_2;
		}
	}
	if(game->tabplayer[0][2] == game->tabplayer[1][2] && game->tabplayer[0][2] == game->tabplayer[2][2]){
		if(game->tabplayer[0][2] == 1){
			winner = PLAYER_1;
		}
		if(game->tabplayer[0][2] == 2){
			winner = PLAYER_2;
		}
	}
	if(game->tabplayer[0][1] == game->tabplayer[1][1] && game->tabplayer[0][1] == game->tabplayer[2][1]){
		if(game->tabplayer[0][1] == 1){
			winner = PLAYER_1;
		}
		if(game->tabplayer[0][1] == 2){
			winner = PLAYER_2;
		}
	}
	if(game->tabplayer[0][0] == game->tabplayer[1][1] && game->tabplayer[0][0] == game->tabplayer[2][2]){
		if(game->tabplayer[0][0] == 1){
			winner = PLAYER_1;
		}
		if(game->tabplayer[0][0] == 2){
			winner = PLAYER_2;
		}
	}
	if(game->tabplayer[1][0] == game->tabplayer[1][1] && game->tabplayer[1][2] == game->tabplayer[1][0]){
		if(game->tabplayer[1][0] == 1){
			winner = PLAYER_1;
		}
		if(game->tabplayer[1][0] == 2){
			winner = PLAYER_2;
		}
	}
	return winner;	
	
}





int get_nb_piece_in_house(board game, player checked_player, size piece_size){
	if(checked_player==1){
		return game->house1[piece_size];
	}
	if(checked_player==2){
		return game->house2[piece_size];
	}
	else{ 
		printf("ERROR JOUEUR NON VALIDE");
		return 0;
	}
		
}
	

enum return_code place_piece(board game, size piece_size, int line, int column){
	if(line>=DIMENSIONS || line<0 || column >= DIMENSIONS || column<0){
		next_player(game);
		return 1;
	}
	if(game->joueur==1){
		if(game->house1[piece_size]==0){
			next_player(game);
			return 2;
		}
	}
	if(game->joueur==2){
		if(game->house2[piece_size]==0){
			next_player(game);
			return 2;
		}
	}
	if(game->tabsize[line][column]>=piece_size){
		next_player(game);
		return 3;
	}
	if(game->tabplayer[line][column]==game->joueur){
		next_player(game);
		return 3;
	}
	game->MEMOIRE[line][column]+=piece_size;
	game->tabsize[line][column]=piece_size;
	game->tabplayer[line][column]=game->joueur;
	if(game->joueur==1){
		game->house1[piece_size]-=1;
	}
	if(game->joueur==2){
		game->house2[piece_size]-=1;
	}
	next_player(game);
	return OK;
}

void afficheplayer(board game){
	for(int a=0;a<DIMENSIONS;a++){
		for(int b=0;b<DIMENSIONS;b++){
			printf("%d",game->tabplayer[a][b]);
		}
	printf("\n");
	}
}
void affichememoire(board game){
	for(int a=0;a<DIMENSIONS;a++){
		for(int b=0;b<DIMENSIONS;b++){
			printf("%d",game->MEMOIRE[a][b]);
		}
	printf("\n");
	}
}


int compteur_memoire(board game,int line,int column){
	if(game->MEMOIRE[line][column]==6){
		return 2;
	}
	if(game->MEMOIRE[line][column]==5){
		return 2;
	}
	if(game->MEMOIRE[line][column]==4){
		return 1;
	}
	if(game->MEMOIRE[line][column]==3){
		return 1;
	}
	return 0;
}




enum return_code move_piece(board game, int source_line, int source_column, int target_line, int target_column){
	if(target_line>=DIMENSIONS || target_line<0 || target_column >= DIMENSIONS || target_column<0 || source_line>=DIMENSIONS || source_line<0 || source_column >= DIMENSIONS || source_column<0){
		next_player(game);
		return 1;
	}
	if(game->tabsize[source_line][source_column]==0){
		next_player(game);
		return 2;
	}
	if(game->tabplayer[source_line][source_column]!=game->joueur){
		next_player(game);
		return 2;
	}
	if(game->tabsize[source_line][source_column]<=game->tabsize[target_line][target_column]){
		next_player(game);
		return 3;
	}
	if(game->MEMOIRE[source_line][source_column] - game->tabsize[source_line][source_column] == 0){
		printf("ici");
		game->MEMOIRE[source_line][source_column] -= game->tabsize[source_line][source_column];
		game->MEMOIRE[target_line][target_column] += game->tabsize[source_line][source_column];
		game->tabsize[target_line][target_column]=game->tabsize[source_line][source_column];
		game->tabplayer[target_line][target_column]=game->tabplayer[source_line][source_column];
		game->tabplayer[source_line][source_column]=0;
		game->tabsize[source_line][source_column]=0;
		next_player(game);
		return 0;	
	}
	else{
		game->MEMOIRE[target_line][target_column] += game->tabsize[source_line][source_column];
		printf("la");
		game->MEMOIRE[source_line][source_column] = compteur_memoire(game,source_line,source_column);

		game->tabsize[target_line][target_column] = game->tabsize[source_line][source_column];
		game->tabsize[source_line][source_column] = game->MEMOIRE[source_line][source_column]; 
		if(game->joueur == 1){
			game->tabplayer[source_line][source_column]=2;
			game->tabplayer[target_line][target_column]=1;
		}
		else{
			game->tabplayer[source_line][source_column]=1;
			game->tabplayer[target_line][target_column]=2;
		}
	}
	next_player(game);
	return 0;
}


	
